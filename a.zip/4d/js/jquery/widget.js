var whenDate = '';		// CHG 
function greek_weekday(x){
var    s = x;
var    result="";
s=s.replace(/Mon/iug, 'Δευ');
s=s.replace(/Tue/iug, 'Τρι');
s=s.replace(/Wed/iug, 'Τετ');
s=s.replace(/Thu/iug, 'Πεμ');
s=s.replace(/Fri/iug, 'Παρ');
s=s.replace(/Sat/iug, 'Σαβ');
s=s.replace(/Sun/iug, 'Κυρ');
result = s;
return(result);
}


function greek_substitutes(x){
var    s = x;
var    result="";
                                // iug 	case-insensitive,unicode,global matching
// unfortunately \b doesn't seem to work with non-latin chars
// This WON'T WORK    s = s.replace(/\bΜάρ[^\b*]*\b/igu,"Mar");
s=s.replace(/σήμ[^ ,/]*/iug,  'today');
s=s.replace(/σημ[^ ,/]*/iug,  'today');
s=s.replace(/αύ[^ ,/]*/iug,  'tomorrow');
s=s.replace(/αυ[^ ,/]*/iug,  'tomorrow');
s=s.replace(/χθ[^ ,/]*/iug,  'yesterday');

s=s.replace(/Ιαν[^ ,/]*/iug,  'Jan');
s=s.replace(/Φεβ[^ ,/]*/iug,  'Feb');
s=s.replace(/Μαρ[^ ,/]*/iug,  'Mar');
s=s.replace(/Μάρ[^ ,/]*/iug,  'Mar');
s=s.replace(/Απρ[^ ,/]*/iug,  'Apr');
s=s.replace(/Άπρ[^ ,/]*/iug,  'Apr');
s=s.replace(/Μαϊ[^ ,/]*/iug,  'May');
s=s.replace(/Μάϊ[^ ,/]*/iug,  'May');
s=s.replace(/Μάι[^ ,/]*/iug,  'May');
s=s.replace(/Ιουν[^ ,/]*/iug, 'Jun');
s=s.replace(/Ιούν[^ ,/]*/iug, 'Jun');
s=s.replace(/Ιουλ[^ ,/]*/iug, 'Jul');
s=s.replace(/Ιούλ[^ ,/]*/iug, 'Jul');
s=s.replace(/Αυγ[^ ,/]*/iug,  'Aug');
s=s.replace(/Αύγ[^ ,/]*/iug,  'Aug');
s=s.replace(/Σεπ[^ ,/]*/iug,  'Sep');
s=s.replace(/Οκτ[^ ,/]*/iug,  'Oct');
s=s.replace(/Νοε[^ ,/]*/iug,  'Nov');
s=s.replace(/Νοέ[^ ,/]*/iug,  'Nov');
s=s.replace(/Δεκ[^ ,/]*/iug,  'Dec');
//
s=s.replace(/Δευ[^ ,/]*/iug, 'Monday');
s=s.replace(/Τρι[^ ,/]*/iug, 'Tueday');
s=s.replace(/Τρί[^ ,/]*/iug, 'Tueday');
s=s.replace(/Τετ[^ ,/]*/iug, 'Wednesday');
s=s.replace(/Πεμ[^ ,/]*/iug, 'Thursday');
s=s.replace(/Πέμ[^ ,/]*/iug, 'Thursday');
s=s.replace(/Παρ[^ ,/]*/iug, 'Friday');
s=s.replace(/Σαβ[^ ,/]*/iug, 'Saturday');
s=s.replace(/Σάβ[^ ,/]*/iug, 'Saturday');
s=s.replace(/Κυρ[^ ,/]*/iug, 'Sunday');
//
s=s.replace(/τώρ[^ ,/]*/iug, 'now');
s=s.replace(/τωρ[^ ,/]*/iug, 'now');
s=s.replace(/επο[^ ,/]*/iug, 'next');
s=s.replace(/επό[^ ,/]*/iug, 'next');
s=s.replace(/προ[^ ,/]*/iug, 'last');
s=s.replace(/εβδ[^ ,/]*/iug, 'week');
s=s.replace(/βδ[^ ,/]*/iug,  'week');
s=s.replace(/ημ[^ ,/]*/iug,  'day');
s=s.replace(/μέρ[^ ,/]*/iug, 'day');
s=s.replace(/μερ[^ ,/]*/iug, 'day');
s=s.replace(/μην[^ ,/]*/iug, 'month');
s=s.replace(/μήν[^ ,/]*/iug, 'month');
s=s.replace(/ετ[^ ,/]*/iug,  'year');
s=s.replace(/έτ[^ ,/]*/iug,  'year');
s=s.replace(/χρ[^ ,/]*/iug,  'year');



s=s.replace(/στ[^ ,/]*/iug,  'at');
//

// the date.js package assumes that 3/4 means Mar 4, instead of Apr 3
s=s.replace(/(\d{1,2})\s*\/\s*(\d{1,2})/, '$2/$1');




result = s;
console.log('x',x, 'Substitution result: ', result);
	return(result);
}
(function () {
	$(document).ready(function () {
		//CHG var messages = ["Nope", "Keep Trying", "Nadda", "Sorry", "No one\'s home", "Arg", "Bummer", "Faux pas", "Whoops", "Snafu", "Blunder"];
		var messages = ["Σφάλμα"];
		var input = $("#when"), date_string = $("#explain_date"), date = null;
		//CHG var input_empty = "*Enter a date (or time) here", empty_string = "Type a date above";
		var input_empty = "", empty_string = "";
		input.val(input_empty);
		date_string.text(empty_string);
		input.keyup( 
			function (e) {
				date_string.removeClass();
				if (input.val().length > 0) {
					//CHG date = Date.parse(input.val());
					date = Date.parse(greek_substitutes(input.val()));
					if (date !== null) {
						input.removeClass();
						//CHG date_string.addClass("accept").text(date.toString("dddd, MMMM dd, yyyy h:mm:ss tt"));
						date_string.addClass("accept").text(greek_weekday(date.toString("ddd dd/MM/yyyy HH:mm")));
		// CHG save correct date value in appropriate format
		whenDate = date.toString("yyyy-MM-dd HH:mm");	//CHG
					} else {
						input.addClass("validate_error");
						date_string.addClass("error").text(messages[Math.round(messages.length * Math.random())] + "...");
					}
				} else {
					date_string.text(empty_string).addClass("empty");
				}
			}
		);
		input.focus( 
			function (e) {
				if (input.val() === input_empty) {
					input.val("");
				}
			}
		);
		input.blur( 
			function (e) {
				if (input.val() === "") {
					input.val(input_empty).removeClass();
				}
			}
		);
		var count = 1;
//CHG		$("#clickme").attr("style", $("#clickme").attr("style") + "cursor:pointer;").click( function (e) {
//CHG			if (count > 4) {
//CHG				count = 1;
//CHG			}
//CHG			$("#ninjaism").attr("src","images/ninjaism" + count + ".png");
//CHG			count++;
//CHG			e.stopPropagation();
//CHG			$(document).click( function (e) {
//CHG				$("#ninjaism").attr("src","images/shim.gif");
//CHG			});
//CHG		});
	});
}());
