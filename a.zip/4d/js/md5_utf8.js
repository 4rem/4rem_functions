// return the md5sum of a (utf-8) string in hex, using openpgpjs functions
// CHG

function md5_utf8(str){ return(
	openpgp.util.hexidump(
	 openpgp.crypto.hash.md5(
	  openpgp.util.str2Uint8Array( 
	   openpgp.util.encode_utf8(
	      str
          )
         )
        )
       )
)}
