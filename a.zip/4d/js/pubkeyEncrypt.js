///  If you don't add     <meta charset="UTF-8">   in the HTML <head>
///  encryption of non-ASCII text may not work properly.
var pubkeyEncrypt_encrypted;

function heredoc(fn){return fn.toString().match(/\/\*\s*([\s\S]*?)\s*\*\//m)[1]; };


function pubkeyEncrypt(msg, _callback){
var pubkey = heredoc(function(){/*

-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: GnuPG v1

mQINBEm4/wIBEADPdZxNayXAFeVLOWj3b1+XrHJ88p+VrgqXRN9xFM7pPWuGlgrc
zfM8EaKgt0OHzlyHRLAWevOhaTWo2jTjcTz9lp19AvVUeBox8E4BBNv+uSCAchG9
nzfgGwQqCRkQwynplrLrLPOJtqyFci4zGJo1zzgZWGTwmLYZpuwnCu01vy9iWGp2
pURYwwRiq7QTXVoBR5UqVXL1OJ5647eKvL6KHOxflPKQ3JWHV7+i6mS21sS1yt30
el17RiYUjqNAg6hKbje1edOtPcMJXBqT6l8r7XxP2gQlGVKKLMHMFZX5s1G+IaZc
M9OnkJK68PiCsKUSiDs8VRJ6w9K36trKPcwRu5+LTF/GiR+3YSNPXXNd7VkJA60I
bobfc3N7tDNQr5JEywG2OB0ZZkPNocGljBLE43r6dWNm0QwXpeX+/glIwzvSdXpH
y7jUEsj6clt1e4NdPEpCOyJ12xqJI2jRd3esxX/MXts5w67mMOo+gasgeb5K581K
z/FJXdCjWF6k4GJ+bQtVIvDzyAhzXUrPVyvi1N1jSE+GgmIzBiPM9Xm9rOj1mjFX
bhk8SgKCnIfjB/uFPXiuYuy8kpGjXxF0gldzyz3K6mEfS44oZwiMIPEdz2Hdgkk0
YZz6gPe1v9hy1B9LqkSK3+eGqrZlWejX+bShpyuMtgfSId0YDrIZq3W/jQARAQAB
tAUuLi4uLokCOAQTAQIAIgUCSbj/AgIbAwYLCQgHAwIGFQgCCQoLBBYCAwECHgEC
F4AACgkQIavIsuDTUv8QXQ//fW/bSnLgPJdLMg3SYObOwnGDgXciX4DzwdlvxTJD
Ddcd5x5cBpLoPnb/y1JXNOa5FePsZYjFwQHCOtQun0DBHn+wxFyTn7uvxSqJWXEx
SOlBXY06AX9Stev4Ye2sAJ/C4gGRQyTa5XOLz3HiOama3vn6jn1T7sUMNmfjbX7i
ZmIQiXuJB+sH4PTtb45RYeQowEn1MMAyQpSO5ing6n7TSI94/s4q8cpQhDG7ZAMX
KCLEqTklat3+p7pHd+egA9T/set1fluNehFfbdKnC9ReNf8D6T2/0w42WeW5ihpG
5AnrPQ2tYFrY5bniKgr+FfraSor2MJeaYkWTO2OmezaOirL2O18Q70aCejh2Z9tD
5F1gWcJi9JF3qvniEpUzVZ6wxaI0LFnYsFBA663W0S62ujAt6QqI7bqto0oox52X
uzXAFsAew/uYp1aj0iBXk3wAFgd8lvUdqQQLti9Bvdb7jySAm3nyU0G6eUOb5PWJ
3z0mpOCM/n9zi/QnyMzQj8PUbmT4iaQ9q3s1C9+/2KHQKJI5ODAq81hLH0HnJtHv
tCdApt0/x4nXx6un1vUmQRF3iGjOkQQZ1DElVGNK8aboEWS3uPFabOIWK4PwagPP
DfMMig9wix9m0jsR6uYm0DPD8l9TjK9mahVhMVnFcWRtGNidQDWzBim/RyIzPAsE
Ihy5Ag0ESbj/AgEQAKWhTFNMomnLZQD1539L4jQUvzOwLRG56buAsP4rLfL7aA6C
pMyErV7L7AD0lamY2z1eiZ2McOL9PWuZWxOIoTo+LwcsXynOPNEWi3lsu82amefo
KgpDEGAj9RZ2jvByzzbfHollLrLvSvjcrzXKwlwKA9QljU2SSXA8Y0kycZPf5sxI
V2taPcb/okIG5sYd0q3074oRtrYC6Vij+SEQBh2Fjqn9mGGYvJjbwGicnKZai+Sc
MXz1Ewij4dIJIpM3PFqLCebLGqjGXueRJnFO7of1npt7XEbEeqYjTcv2UBTGB1Qi
Mh6dcdKjDIwL/bamle+gGYf51g6Kyl7aMK350geRQuUA2FoL13fQzXkV7d8qa21E
7dRqN7OeNKO6lwW32VqnJLHuTILE3+Zx6jpNCmPRzpcuvsY+T3iyk9gXTnbXYwyJ
tX0CC2WqEZmX2jWI9UlYurzIxJ+cBZzdLSZ8jPYXCasOJlT9BlcwG++kkSfxH7C8
x2YbF4VOindhVf1bFhWU9rg7G53G5/RIDBO8Eq9oFbKGXP+ezwrJLYxbWTTbZnuY
EgbTQNkDcEgmpxWEpZJvpNNs3CfmayS1iXrhYFEpvI/UZ+GgZeDFiBNrW73l3cAy
mzz9pE7mHZoyy3qguL3iAV/cL2nNz6nYQkBnW5TZYXqBuS05X/077vsTKsaXABEB
AAGJAh8EGAECAAkFAkm4/wICGwwACgkQIavIsuDTUv9ZVw/+KVDNuMJA9sBWCEnI
1ghQyNetWaMimaFk1wnYNK5/7PgyAgdjG8eznKTq++/US1HCQdlDgjWzx2IB3xFo
JVndkfsR2Gv0GYQ9036XrCQ8REUaPTWwg8t/6BbNkJRYKnts9dBuiQ+n3W7gojXK
Ot94tGq8rltrTJUCWynAimLXY9ynI7OxmNFMdHPYn0Yu3lFR7x19IiZjr7BMWLNo
3IOyi8TezjIZNXZXSPkjGK1Qdl+aic4Tzr/kmX3bpCvdGyx4kKUiaQprxa5rbgXD
N0jNBunXcwObNNMn/Wfn0+6nLI7jG/WoDdWmmJgPMZtrBJ37TF9WEmRk5b4Ol3Xr
H5aDcEhfVX7NS2eVFwZsvHOsqKzD/nIWu1Z4MqcvNga7SmMKRf16Kl4yaLwMQt2J
KRPmjD5wqPyHgsd/e9vvoTzAtGhXQdNRguCUEAjMAnog3AQRlrSc42IoaKrBNBjo
uEIApZZ0Y0TcHgYS0qetc77JxBRf8lTSKJZ3ewc/PLRZn/gRoRp6ApABCFjER1Ey
BoDZHL2fdZldoTty6/vBtLKh/4MRp+tFpyXP3At3+rHCvWItWm8mMuYnyz79Ao/5
InB0UkUmmiUogIDlcklnFx1zV4FZp41czpyorMe60XHCTk0Gs/aukXbtP7wKUur+
cJAPGToZ4ivmlmZF6QJ1enad6J0=
=FYIi
-----END PGP PUBLIC KEY BLOCK-----

*/});

var options = {
    data: msg, // input as String (or Uint8Array)
    publicKeys: openpgp.key.readArmored(pubkey).keys,  // for encryption
    armor: true,
    //privateKeys: privKeyObj // for signing (optional)
};


// see: http://openpgpjs.org/openpgpjs/doc/module-openpgp.html
openpgp.encrypt(options).then(function(ciphertext) {
    pubkeyEncrypt_encrypted = ciphertext.data;
    		 // '-----BEGIN PGP MESSAGE ... END PGP MESSAGE-----'
   _callback();
});

}
